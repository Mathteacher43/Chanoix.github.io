
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Player, Bullet, Particle, GameState, AIEvent, Upgrade } from './types';
import { GAME_WIDTH, GAME_HEIGHT, PLAYER_SIZE, BULLET_SPEED, BULLET_LIFE, FIRE_RATE, MAX_BOTS, PLAYER_COLORS } from './constants';
import { getAITaunt, getTacticalUpdate, generateBotProfile } from './services/geminiService';
import GameCanvas from './components/GameCanvas';
import HUD from './components/HUD';

const UPGRADES: Upgrade[] = [
  { id: 'speed', name: 'Neon Thrusters', description: '+20% Movement Speed', effect: (p) => { p.speed += 1; } },
  { id: 'firerate', name: 'Reflex Overclock', description: '+25% Fire Rate', effect: (p) => { p.fireRate = Math.max(80, p.fireRate - 40); } },
  { id: 'damage', name: 'Tungsten Rounds', description: '+50% Bullet Damage', effect: (p) => { p.damage += 5; } },
  { id: 'health', name: 'Titan Plating', description: '+50 Max HP & Full Heal', effect: (p) => { p.maxHealth += 50; p.health = p.maxHealth; } },
];

const App: React.FC = () => {
  const [gameState, setGameState] = useState<GameState | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [playerName, setPlayerName] = useState('CyberHunter');
  const [events, setEvents] = useState<AIEvent[]>([]);
  const [showUpgrade, setShowUpgrade] = useState(false);
  const [availableUpgrades, setAvailableUpgrades] = useState<Upgrade[]>([]);
  const [screenShake, setScreenShake] = useState(0);
  
  const stateRef = useRef<GameState | null>(null);
  const requestRef = useRef<number | null>(null);
  const keysPressed = useRef<Set<string>>(new Set());
  const mousePos = useRef({ x: 0, y: 0 });
  const isMouseDown = useRef(false);
  const lastTauntTime = useRef(0);

  const startGame = useCallback(async () => {
    const initialPlayer: Player = {
      id: 'local-player',
      name: playerName || 'Player',
      pos: { x: GAME_WIDTH / 2, y: GAME_HEIGHT / 2 },
      angle: 0,
      health: 100,
      maxHealth: 100,
      score: 0,
      level: 1,
      color: PLAYER_COLORS[0],
      isBot: false,
      lastShot: 0,
      isDead: false,
      speed: 5,
      fireRate: FIRE_RATE,
      damage: 15
    };

    const initialBots: Player[] = [];
    for (let i = 0; i < 6; i++) {
      const profile = await generateBotProfile();
      initialBots.push({
        id: `bot-${i}-${Date.now()}`,
        name: profile.name,
        pos: { x: Math.random() * GAME_WIDTH, y: Math.random() * GAME_HEIGHT },
        angle: Math.random() * Math.PI * 2,
        health: 100,
        maxHealth: 100,
        score: 0,
        level: 1,
        color: PLAYER_COLORS[(i + 1) % PLAYER_COLORS.length],
        isBot: true,
        lastShot: 0,
        isDead: false,
        speed: 3,
        fireRate: FIRE_RATE * 2,
        damage: 10
      });
    }

    const initialState: GameState = {
      player: initialPlayer,
      others: initialBots,
      bullets: [],
      particles: []
    };

    stateRef.current = initialState;
    setGameState(initialState);
    setIsPlaying(true);
    setEvents([{ type: 'tactical' as const, sender: 'System', message: 'Augmentation protocol online. Destroy hostiles.' }]);
  }, [playerName]);

  const handleUpgrade = (upgrade: Upgrade) => {
    if (!stateRef.current) return;
    upgrade.effect(stateRef.current.player);
    setShowUpgrade(false);
    setIsPlaying(true);
    setEvents(prev => [{ type: 'levelUp' as const, sender: 'SYSTEM', message: `Augment Integrated: ${upgrade.name}` }, ...prev].slice(0, 5));
  };

  const update = useCallback((time: number) => {
    if (!stateRef.current || !isPlaying || showUpgrade) return;

    const state = { ...stateRef.current };
    const { player, others, bullets, particles } = state;

    // 1. Player Movement
    if (keysPressed.current.has('w')) player.pos.y -= player.speed;
    if (keysPressed.current.has('s')) player.pos.y += player.speed;
    if (keysPressed.current.has('a')) player.pos.x -= player.speed;
    if (keysPressed.current.has('d')) player.pos.x += player.speed;

    player.pos.x = Math.max(PLAYER_SIZE, Math.min(GAME_WIDTH - PLAYER_SIZE, player.pos.x));
    player.pos.y = Math.max(PLAYER_SIZE, Math.min(GAME_HEIGHT - PLAYER_SIZE, player.pos.y));

    const dx = mousePos.current.x - window.innerWidth / 2;
    const dy = mousePos.current.y - window.innerHeight / 2;
    player.angle = Math.atan2(dy, dx);

    const now = Date.now();
    if (isMouseDown.current && now - player.lastShot > player.fireRate) {
      bullets.push({
        id: `b-${now}`,
        ownerId: player.id,
        pos: { ...player.pos },
        velocity: { x: Math.cos(player.angle) * BULLET_SPEED, y: Math.sin(player.angle) * BULLET_SPEED },
        damage: player.damage,
        color: '#60a5fa',
        life: BULLET_LIFE
      });
      player.lastShot = now;
    }

    // 2. Bots AI
    others.forEach(bot => {
      if (bot.isDead) return;
      const dist = Math.sqrt((player.pos.x - bot.pos.x)**2 + (player.pos.y - bot.pos.y)**2);
      if (dist < 700) {
        bot.angle = Math.atan2(player.pos.y - bot.pos.y, player.pos.x - bot.pos.x);
        bot.pos.x += Math.cos(bot.angle) * bot.speed;
        bot.pos.y += Math.sin(bot.angle) * bot.speed;
        if (now - bot.lastShot > bot.fireRate && Math.random() < 0.05) {
          bullets.push({
            id: `bb-${now}-${bot.id}`,
            ownerId: bot.id,
            pos: { ...bot.pos },
            velocity: { x: Math.cos(bot.angle) * BULLET_SPEED, y: Math.sin(bot.angle) * BULLET_SPEED },
            damage: bot.damage,
            color: bot.color,
            life: BULLET_LIFE
          });
          bot.lastShot = now;
        }
      } else {
        bot.pos.x += Math.cos(bot.angle) * 1;
        bot.pos.y += Math.sin(bot.angle) * 1;
        if (Math.random() < 0.02) bot.angle += (Math.random() - 0.5);
      }
      bot.pos.x = Math.max(PLAYER_SIZE, Math.min(GAME_WIDTH - PLAYER_SIZE, bot.pos.x));
      bot.pos.y = Math.max(PLAYER_SIZE, Math.min(GAME_HEIGHT - PLAYER_SIZE, bot.pos.y));
    });

    // 3. Bullets & Collisions
    for (let i = bullets.length - 1; i >= 0; i--) {
      const b = bullets[i];
      b.pos.x += b.velocity.x;
      b.pos.y += b.velocity.y;
      b.life--;

      if (b.life <= 0) {
        bullets.splice(i, 1);
        continue;
      }

      const targets = [player, ...others];
      for (const t of targets) {
        if (b.ownerId === t.id || t.isDead) continue;
        const d = Math.sqrt((b.pos.x - t.pos.x)**2 + (b.pos.y - t.pos.y)**2);
        if (d < PLAYER_SIZE) {
          t.health = Math.max(0, t.health - b.damage);
          if (t.id === 'local-player') setScreenShake(10);
          
          for(let k=0; k<3; k++) particles.push({
            pos: { ...b.pos },
            velocity: { x: (Math.random()-0.5)*8, y: (Math.random()-0.5)*8 },
            life: 15, color: t.color, size: 2 + Math.random()*3
          });
          
          bullets.splice(i, 1);
          if (t.health <= 0) handleKill(b.ownerId, t.id);
          break;
        }
      }
    }

    // 4. Particles
    for (let i = particles.length - 1; i >= 0; i--) {
      particles[i].pos.x += particles[i].velocity.x;
      particles[i].pos.y += particles[i].velocity.y;
      particles[i].life--;
      if (particles[i].life <= 0) particles.splice(i, 1);
    }

    if (screenShake > 0) setScreenShake(s => Math.max(0, s - 1));

    stateRef.current = state;
    setGameState({ ...state });
    requestRef.current = requestAnimationFrame(update);
  }, [isPlaying, showUpgrade, screenShake]);

  const handleKill = async (killerId: string, victimId: string) => {
    const state = stateRef.current;
    if (!state) return;

    const all = [state.player, ...state.others];
    const killer = all.find(p => p.id === killerId);
    const victim = all.find(p => p.id === victimId);

    if (killer && victim && !victim.isDead) {
      victim.isDead = true;
      killer.score += 150;
      
      // Level Up Check
      const oldLevel = killer.level;
      killer.level = Math.floor(killer.score / 500) + 1;
      
      if (killer.id === 'local-player' && killer.level > oldLevel) {
        setIsPlaying(false);
        const shuffled = [...UPGRADES].sort(() => 0.5 - Math.random()).slice(0, 3);
        setAvailableUpgrades(shuffled);
        setShowUpgrade(true);
      }

      setEvents(prev => [{ type: 'kill' as const, sender: 'SYSTEM', message: `${killer.name} [DELETED] ${victim.name}` }, ...prev].slice(0, 5));

      const now = Date.now();
      if (now - lastTauntTime.current > 10000) {
        lastTauntTime.current = now;
        getAITaunt(killer.name, victim.name).then(taunt => {
          setEvents(prev => [{ type: 'taunt' as const, sender: killer.name, message: taunt }, ...prev].slice(0, 5));
        });
      }

      // Safe Respawn Delay
      setTimeout(() => {
        if (stateRef.current) {
          const v = stateRef.current.others.find(o => o.id === victim.id) || (stateRef.current.player.id === victim.id ? stateRef.current.player : null);
          if (v) {
            v.health = v.maxHealth;
            v.isDead = false;
            v.pos = { x: Math.random() * GAME_WIDTH, y: Math.random() * GAME_HEIGHT };
          }
        }
      }, 2000);
    }
  };

  useEffect(() => {
    if (isPlaying && !showUpgrade) requestRef.current = requestAnimationFrame(update);
    return () => { if (requestRef.current) cancelAnimationFrame(requestRef.current); };
  }, [isPlaying, showUpgrade, update]);

  useEffect(() => {
    const handleKD = (e: KeyboardEvent) => keysPressed.current.add(e.key.toLowerCase());
    const handleKU = (e: KeyboardEvent) => keysPressed.current.delete(e.key.toLowerCase());
    const handleMM = (e: MouseEvent) => { mousePos.current = { x: e.clientX, y: e.clientY }; };
    const handleMD = () => (isMouseDown.current = true);
    const handleMU = () => (isMouseDown.current = false);
    window.addEventListener('keydown', handleKD);
    window.addEventListener('keyup', handleKU);
    window.addEventListener('mousemove', handleMM);
    window.addEventListener('mousedown', handleMD);
    window.addEventListener('mouseup', handleMU);
    return () => {
      window.removeEventListener('keydown', handleKD);
      window.removeEventListener('keyup', handleKU);
      window.removeEventListener('mousemove', handleMM);
      window.removeEventListener('mousedown', handleMD);
      window.removeEventListener('mouseup', handleMU);
    };
  }, []);

  if (!isPlaying && !showUpgrade) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-slate-950 p-6">
        <div className="bg-slate-900 border border-blue-500/30 p-10 rounded-2xl shadow-2xl max-w-md w-full">
          <h1 className="text-5xl font-black text-center mb-2 bg-gradient-to-r from-blue-400 to-cyan-300 bg-clip-text text-transparent italic">GEMINI ARENA</h1>
          <p className="text-slate-400 text-center mb-8 uppercase tracking-widest text-xs font-bold">Augmentation Protocol v2.0</p>
          <input type="text" value={playerName} onChange={(e) => setPlayerName(e.target.value)} className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-lg text-white mb-6 outline-none focus:ring-2 focus:ring-blue-500" placeholder="Operator Name" />
          <button onClick={startGame} className="w-full py-4 bg-blue-600 hover:bg-blue-500 text-white font-black rounded-lg uppercase tracking-widest transition-all">Connect to Arena</button>
        </div>
      </div>
    );
  }

  return (
    <div className="relative w-full h-screen overflow-hidden bg-slate-950">
      <GameCanvas gameState={gameState} shake={screenShake} />
      <HUD player={gameState?.player || null} others={gameState?.others || []} events={events} />
      
      {showUpgrade && (
        <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-md flex flex-col items-center justify-center z-50 p-10">
          <h2 className="text-4xl font-black text-blue-400 mb-2 italic">LEVEL UP DETECTED</h2>
          <p className="text-slate-400 mb-10 uppercase tracking-widest">Select Cybernetic Augmentation</p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl w-full">
            {availableUpgrades.map(u => (
              <button key={u.id} onClick={() => handleUpgrade(u)} className="p-6 bg-slate-900 border border-slate-700 hover:border-blue-500 rounded-xl transition-all group text-left">
                <h3 className="text-xl font-bold text-white group-hover:text-blue-400 mb-2">{u.name}</h3>
                <p className="text-slate-500 text-sm">{u.description}</p>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default App;
