
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getAITaunt = async (killer: string, victim: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `You are a competitive gamer in a 2D top-down shooter. Write a short, toxic but funny one-liner taunt from '${killer}' who just defeated '${victim}'. Keep it under 15 words. Use gamer slang.`,
      config: {
        thinkingConfig: { thinkingBudget: 0 }
      }
    });
    return response.text || "GG WP!";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Next time, try moving!";
  }
};

export const getTacticalUpdate = async (playerScore: number, botCount: number) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Current arena status: Player Score: ${playerScore}, AI Bots: ${botCount}. Provide a short "Command Center" announcement about the state of the battle. Keep it dramatic and sci-fi. Max 20 words.`,
      config: {
        thinkingConfig: { thinkingBudget: 0 }
      }
    });
    return response.text || "Multiple hostiles detected. Stay sharp.";
  } catch (error) {
    return "Battle continues in the neon district.";
  }
};

export const generateBotProfile = async () => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: "Generate a cool cyberpunk gamer handle and a short personality trait (e.g., 'Aggressive', 'Sniper', 'Troll'). Return as JSON.",
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            name: { type: Type.STRING },
            trait: { type: Type.STRING }
          },
          required: ["name", "trait"]
        }
      }
    });
    return JSON.parse(response.text);
  } catch (error) {
    return { name: `Bot_${Math.floor(Math.random() * 1000)}`, trait: "Unpredictable" };
  }
};
