
export const GAME_WIDTH = 2000;
export const GAME_HEIGHT = 2000;
export const PLAYER_SIZE = 40;
export const BULLET_SPEED = 12;
export const BULLET_LIFE = 100;
export const FIRE_RATE = 150; // ms
export const MAX_BOTS = 10;
export const PLAYER_COLORS = [
  '#3b82f6', // blue
  '#ef4444', // red
  '#10b981', // green
  '#f59e0b', // amber
  '#8b5cf6', // violet
  '#ec4899', // pink
  '#06b6d4', // cyan
];
