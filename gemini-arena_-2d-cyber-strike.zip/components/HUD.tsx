
import React from 'react';
import { Player, AIEvent } from '../types';

interface Props {
  player: Player | null;
  others: Player[];
  events: AIEvent[];
}

const HUD: React.FC<Props> = ({ player, others, events }) => {
  if (!player) return null;

  const leaderboard = [player, ...others]
    .sort((a, b) => b.score - a.score)
    .slice(0, 5);

  const nextLevelScore = player.level * 500;
  const currentLevelBase = (player.level - 1) * 500;
  const xpProgress = ((player.score - currentLevelBase) / (nextLevelScore - currentLevelBase)) * 100;

  return (
    <div className="absolute inset-0 pointer-events-none select-none p-6 font-sans flex flex-col justify-between">
      <div className="flex justify-between items-start">
        {/* Stats */}
        <div className="bg-slate-900/90 backdrop-blur-md border border-slate-700/50 p-4 rounded-xl shadow-2xl w-72">
          <div className="flex justify-between items-center mb-2">
            <span className="text-blue-400 font-black text-xl italic">{player.name}</span>
            <span className="bg-blue-600 text-white text-[10px] font-bold px-2 py-0.5 rounded">LVL {player.level}</span>
          </div>
          
          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-[10px] text-slate-500 font-bold uppercase mb-1">
                <span>Core Integrity</span>
                <span>{Math.ceil(player.health)}%</span>
              </div>
              <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden border border-slate-700">
                <div className={`h-full transition-all duration-300 ${player.health > 40 ? 'bg-emerald-500' : 'bg-rose-500'}`} style={{ width: `${(player.health/player.maxHealth)*100}%` }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-[10px] text-slate-500 font-bold uppercase mb-1">
                <span>Experience</span>
                <span>{player.score} / {nextLevelScore}</span>
              </div>
              <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden border border-slate-700">
                <div className="h-full bg-cyan-400 transition-all duration-500" style={{ width: `${xpProgress}%` }} />
              </div>
            </div>
          </div>
        </div>

        {/* Leaderboard */}
        <div className="bg-slate-900/90 backdrop-blur-md border border-slate-700/50 p-4 rounded-xl shadow-2xl w-56">
          <h3 className="text-slate-500 text-[10px] font-black uppercase tracking-widest mb-3 border-b border-slate-800 pb-2">Arena Rankings</h3>
          <div className="space-y-2">
            {leaderboard.map((p, i) => (
              <div key={p.id} className={`flex justify-between items-center ${p.id === player.id ? 'text-blue-400 font-bold' : 'text-slate-400'}`}>
                <span className="text-xs truncate max-w-[100px]">{i + 1}. {p.name}</span>
                <span className="text-[10px] font-mono">{p.score}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex flex-col-reverse gap-2 max-w-sm mb-4">
        {events.map((ev, i) => (
          <div key={i} className={`p-3 rounded border backdrop-blur-md animate-fade-in shadow-lg ${
            ev.type === 'kill' ? 'bg-rose-950/40 border-rose-500/30 text-rose-300' :
            ev.type === 'levelUp' ? 'bg-blue-900/40 border-blue-400/50 text-blue-200' :
            ev.type === 'taunt' ? 'bg-cyan-950/40 border-cyan-500/30 text-cyan-100' :
            'bg-slate-900/40 border-slate-700/30 text-slate-400'
          }`}>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-[9px] font-black uppercase tracking-tighter opacity-50">{ev.sender}</span>
            </div>
            <p className="text-xs leading-tight">{ev.message}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default HUD;
