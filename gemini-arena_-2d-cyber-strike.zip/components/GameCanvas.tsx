
import React, { useRef, useEffect } from 'react';
import { GameState } from '../types';
import { GAME_WIDTH, GAME_HEIGHT, PLAYER_SIZE } from '../constants';

interface Props {
  gameState: GameState | null;
  shake?: number;
}

const GameCanvas: React.FC<Props> = ({ gameState, shake = 0 }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !gameState) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const { player, others, bullets, particles } = gameState;

    ctx.fillStyle = '#0f172a';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.save();
    
    // Apply Shake
    if (shake > 0) {
      const sx = (Math.random() - 0.5) * shake;
      const sy = (Math.random() - 0.5) * shake;
      ctx.translate(sx, sy);
    }

    const camX = -player.pos.x + canvas.width / 2;
    const camY = -player.pos.y + canvas.height / 2;
    ctx.translate(camX, camY);

    // Grid
    ctx.strokeStyle = '#1e293b';
    ctx.lineWidth = 1;
    for (let x = 0; x <= GAME_WIDTH; x += 100) {
      ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, GAME_HEIGHT); ctx.stroke();
    }
    for (let y = 0; y <= GAME_HEIGHT; y += 100) {
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(GAME_WIDTH, y); ctx.stroke();
    }

    ctx.strokeStyle = '#334155';
    ctx.lineWidth = 4;
    ctx.strokeRect(0, 0, GAME_WIDTH, GAME_HEIGHT);

    particles.forEach(p => {
      ctx.globalAlpha = p.life / 15;
      ctx.fillStyle = p.color;
      ctx.fillRect(p.pos.x, p.pos.y, p.size, p.size);
    });
    ctx.globalAlpha = 1;

    bullets.forEach(b => {
      ctx.fillStyle = b.color;
      ctx.beginPath(); ctx.arc(b.pos.x, b.pos.y, 4, 0, Math.PI * 2); ctx.fill();
    });

    const all = [player, ...others];
    all.forEach(p => {
      if (p.isDead) {
        ctx.globalAlpha = 0.3;
        ctx.fillStyle = '#1e293b';
        ctx.beginPath(); ctx.arc(p.pos.x, p.pos.y, PLAYER_SIZE/2, 0, Math.PI*2); ctx.fill();
        ctx.globalAlpha = 1;
        return;
      }
      ctx.save();
      ctx.translate(p.pos.x, p.pos.y);
      ctx.rotate(p.angle);
      ctx.fillStyle = p.color;
      ctx.beginPath(); ctx.roundRect(-PLAYER_SIZE/2, -PLAYER_SIZE/2, PLAYER_SIZE, PLAYER_SIZE, 8); ctx.fill();
      ctx.fillStyle = '#cbd5e1'; ctx.fillRect(PLAYER_SIZE/4, -4, 25, 8);
      ctx.fillStyle = '#000'; ctx.fillRect(5, -12, 6, 24);
      ctx.restore();

      const hbW = 60;
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(p.pos.x - hbW/2, p.pos.y - PLAYER_SIZE - 10, hbW, 6);
      ctx.fillStyle = p.health > 30 ? '#10b981' : '#ef4444';
      ctx.fillRect(p.pos.x - hbW/2, p.pos.y - PLAYER_SIZE - 10, (p.health/p.maxHealth) * hbW, 6);

      ctx.fillStyle = '#f8fafc';
      ctx.font = 'bold 10px Inter';
      ctx.textAlign = 'center';
      ctx.fillText(`LVL ${p.level} ${p.name}`, p.pos.x, p.pos.y - PLAYER_SIZE - 20);
    });

    ctx.restore();
  }, [gameState, shake]);

  return <canvas ref={canvasRef} className="cursor-crosshair" />;
};

export default GameCanvas;
