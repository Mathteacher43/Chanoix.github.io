
export interface Vector2 {
  x: number;
  y: number;
}

export interface Player {
  id: string;
  name: string;
  pos: Vector2;
  angle: number;
  health: number;
  maxHealth: number;
  score: number;
  level: number;
  color: string;
  isBot: boolean;
  lastShot: number;
  isDead: boolean;
  // Stats for Upgrades
  speed: number;
  fireRate: number;
  damage: number;
}

export interface Bullet {
  id: string;
  ownerId: string;
  pos: Vector2;
  velocity: Vector2;
  damage: number;
  color: string;
  life: number;
}

export interface Particle {
  pos: Vector2;
  velocity: Vector2;
  life: number;
  color: string;
  size: number;
}

export interface GameState {
  player: Player;
  others: Player[];
  bullets: Bullet[];
  particles: Particle[];
}

export interface AIEvent {
  type: 'spawn' | 'kill' | 'taunt' | 'tactical' | 'levelUp';
  message: string;
  sender: string;
}

export interface Upgrade {
  id: string;
  name: string;
  description: string;
  effect: (p: Player) => void;
}
